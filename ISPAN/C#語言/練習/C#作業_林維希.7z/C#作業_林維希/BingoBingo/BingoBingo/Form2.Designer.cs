﻿
namespace BingoBingo
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label23 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.labOddorEvenorDeuceBall = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.labBall18 = new System.Windows.Forms.Label();
            this.labBall12 = new System.Windows.Forms.Label();
            this.labBall1 = new System.Windows.Forms.Label();
            this.labBall13 = new System.Windows.Forms.Label();
            this.labBall10 = new System.Windows.Forms.Label();
            this.labBall14 = new System.Windows.Forms.Label();
            this.labBall9 = new System.Windows.Forms.Label();
            this.labBall15 = new System.Windows.Forms.Label();
            this.labBall8 = new System.Windows.Forms.Label();
            this.labBall16 = new System.Windows.Forms.Label();
            this.labBall7 = new System.Windows.Forms.Label();
            this.labBall17 = new System.Windows.Forms.Label();
            this.labBall6 = new System.Windows.Forms.Label();
            this.labBall5 = new System.Windows.Forms.Label();
            this.labBall19 = new System.Windows.Forms.Label();
            this.labBall4 = new System.Windows.Forms.Label();
            this.labBall20 = new System.Windows.Forms.Label();
            this.labBall3 = new System.Windows.Forms.Label();
            this.labBall11 = new System.Windows.Forms.Label();
            this.labBall2 = new System.Windows.Forms.Label();
            this.labSuperBall = new System.Windows.Forms.Label();
            this.labBigSmallBall = new System.Windows.Forms.Label();
            this.btnAgain = new System.Windows.Forms.Button();
            this.msgAll = new System.Windows.Forms.Label();
            this.msg2 = new System.Windows.Forms.Label();
            this.msg = new System.Windows.Forms.GroupBox();
            this.groupBox1.SuspendLayout();
            this.msg.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label23);
            this.groupBox1.Controls.Add(this.label22);
            this.groupBox1.Controls.Add(this.labOddorEvenorDeuceBall);
            this.groupBox1.Controls.Add(this.label21);
            this.groupBox1.Controls.Add(this.label20);
            this.groupBox1.Controls.Add(this.labBall18);
            this.groupBox1.Controls.Add(this.labBall12);
            this.groupBox1.Controls.Add(this.labBall1);
            this.groupBox1.Controls.Add(this.labBall13);
            this.groupBox1.Controls.Add(this.labBall10);
            this.groupBox1.Controls.Add(this.labBall14);
            this.groupBox1.Controls.Add(this.labBall9);
            this.groupBox1.Controls.Add(this.labBall15);
            this.groupBox1.Controls.Add(this.labBall8);
            this.groupBox1.Controls.Add(this.labBall16);
            this.groupBox1.Controls.Add(this.labBall7);
            this.groupBox1.Controls.Add(this.labBall17);
            this.groupBox1.Controls.Add(this.labBall6);
            this.groupBox1.Controls.Add(this.labBall5);
            this.groupBox1.Controls.Add(this.labBall19);
            this.groupBox1.Controls.Add(this.labBall4);
            this.groupBox1.Controls.Add(this.labBall20);
            this.groupBox1.Controls.Add(this.labBall3);
            this.groupBox1.Controls.Add(this.labBall11);
            this.groupBox1.Controls.Add(this.labBall2);
            this.groupBox1.Controls.Add(this.labSuperBall);
            this.groupBox1.Controls.Add(this.labBigSmallBall);
            this.groupBox1.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.groupBox1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.groupBox1.Location = new System.Drawing.Point(12, 40);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(795, 201);
            this.groupBox1.TabIndex = 34;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "開獎號碼";
            // 
            // label23
            // 
            this.label23.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label23.Location = new System.Drawing.Point(732, 18);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(43, 82);
            this.label23.TabIndex = 36;
            this.label23.Text = "猜單雙";
            this.label23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label22
            // 
            this.label22.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label22.Location = new System.Drawing.Point(666, 18);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(43, 82);
            this.label22.TabIndex = 35;
            this.label22.Text = "猜大小";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labOddorEvenorDeuceBall
            // 
            this.labOddorEvenorDeuceBall.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labOddorEvenorDeuceBall.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.labOddorEvenorDeuceBall.Image = ((System.Drawing.Image)(resources.GetObject("labOddorEvenorDeuceBall.Image")));
            this.labOddorEvenorDeuceBall.Location = new System.Drawing.Point(717, 100);
            this.labOddorEvenorDeuceBall.Name = "labOddorEvenorDeuceBall";
            this.labOddorEvenorDeuceBall.Size = new System.Drawing.Size(72, 96);
            this.labOddorEvenorDeuceBall.TabIndex = 22;
            this.labOddorEvenorDeuceBall.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label21
            // 
            this.label21.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label21.Location = new System.Drawing.Point(592, 18);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(62, 65);
            this.label21.TabIndex = 34;
            this.label21.Text = "超級獎號";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label20
            // 
            this.label20.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label20.Location = new System.Drawing.Point(35, 31);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(547, 25);
            this.label20.TabIndex = 33;
            this.label20.Text = "獎號";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labBall18
            // 
            this.labBall18.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labBall18.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.labBall18.Image = ((System.Drawing.Image)(resources.GetObject("labBall18.Image")));
            this.labBall18.Location = new System.Drawing.Point(415, 124);
            this.labBall18.Name = "labBall18";
            this.labBall18.Size = new System.Drawing.Size(58, 57);
            this.labBall18.TabIndex = 26;
            this.labBall18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labBall12
            // 
            this.labBall12.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labBall12.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.labBall12.Image = ((System.Drawing.Image)(resources.GetObject("labBall12.Image")));
            this.labBall12.Location = new System.Drawing.Point(88, 124);
            this.labBall12.Name = "labBall12";
            this.labBall12.Size = new System.Drawing.Size(58, 57);
            this.labBall12.TabIndex = 32;
            this.labBall12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labBall1
            // 
            this.labBall1.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labBall1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.labBall1.Image = ((System.Drawing.Image)(resources.GetObject("labBall1.Image")));
            this.labBall1.Location = new System.Drawing.Point(34, 67);
            this.labBall1.Name = "labBall1";
            this.labBall1.Size = new System.Drawing.Size(58, 57);
            this.labBall1.TabIndex = 0;
            this.labBall1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labBall13
            // 
            this.labBall13.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labBall13.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.labBall13.Image = ((System.Drawing.Image)(resources.GetObject("labBall13.Image")));
            this.labBall13.Location = new System.Drawing.Point(142, 124);
            this.labBall13.Name = "labBall13";
            this.labBall13.Size = new System.Drawing.Size(58, 57);
            this.labBall13.TabIndex = 31;
            this.labBall13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labBall10
            // 
            this.labBall10.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labBall10.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.labBall10.Image = global::BingoBingo.Properties.Resources.yellow;
            this.labBall10.Location = new System.Drawing.Point(524, 67);
            this.labBall10.Name = "labBall10";
            this.labBall10.Size = new System.Drawing.Size(58, 57);
            this.labBall10.TabIndex = 11;
            this.labBall10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labBall14
            // 
            this.labBall14.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labBall14.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.labBall14.Image = ((System.Drawing.Image)(resources.GetObject("labBall14.Image")));
            this.labBall14.Location = new System.Drawing.Point(197, 124);
            this.labBall14.Name = "labBall14";
            this.labBall14.Size = new System.Drawing.Size(58, 57);
            this.labBall14.TabIndex = 30;
            this.labBall14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labBall9
            // 
            this.labBall9.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labBall9.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.labBall9.Image = ((System.Drawing.Image)(resources.GetObject("labBall9.Image")));
            this.labBall9.Location = new System.Drawing.Point(470, 67);
            this.labBall9.Name = "labBall9";
            this.labBall9.Size = new System.Drawing.Size(58, 57);
            this.labBall9.TabIndex = 12;
            this.labBall9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labBall15
            // 
            this.labBall15.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labBall15.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.labBall15.Image = ((System.Drawing.Image)(resources.GetObject("labBall15.Image")));
            this.labBall15.Location = new System.Drawing.Point(251, 124);
            this.labBall15.Name = "labBall15";
            this.labBall15.Size = new System.Drawing.Size(58, 57);
            this.labBall15.TabIndex = 29;
            this.labBall15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labBall8
            // 
            this.labBall8.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labBall8.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.labBall8.Image = ((System.Drawing.Image)(resources.GetObject("labBall8.Image")));
            this.labBall8.Location = new System.Drawing.Point(415, 67);
            this.labBall8.Name = "labBall8";
            this.labBall8.Size = new System.Drawing.Size(58, 57);
            this.labBall8.TabIndex = 13;
            this.labBall8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labBall16
            // 
            this.labBall16.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labBall16.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.labBall16.Image = ((System.Drawing.Image)(resources.GetObject("labBall16.Image")));
            this.labBall16.Location = new System.Drawing.Point(305, 124);
            this.labBall16.Name = "labBall16";
            this.labBall16.Size = new System.Drawing.Size(58, 57);
            this.labBall16.TabIndex = 28;
            this.labBall16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labBall7
            // 
            this.labBall7.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labBall7.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.labBall7.Image = ((System.Drawing.Image)(resources.GetObject("labBall7.Image")));
            this.labBall7.Location = new System.Drawing.Point(360, 67);
            this.labBall7.Name = "labBall7";
            this.labBall7.Size = new System.Drawing.Size(58, 57);
            this.labBall7.TabIndex = 14;
            this.labBall7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labBall17
            // 
            this.labBall17.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labBall17.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.labBall17.Image = ((System.Drawing.Image)(resources.GetObject("labBall17.Image")));
            this.labBall17.Location = new System.Drawing.Point(360, 124);
            this.labBall17.Name = "labBall17";
            this.labBall17.Size = new System.Drawing.Size(58, 57);
            this.labBall17.TabIndex = 27;
            this.labBall17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labBall6
            // 
            this.labBall6.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labBall6.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.labBall6.Image = ((System.Drawing.Image)(resources.GetObject("labBall6.Image")));
            this.labBall6.Location = new System.Drawing.Point(305, 67);
            this.labBall6.Name = "labBall6";
            this.labBall6.Size = new System.Drawing.Size(58, 57);
            this.labBall6.TabIndex = 15;
            this.labBall6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labBall5
            // 
            this.labBall5.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labBall5.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.labBall5.Image = ((System.Drawing.Image)(resources.GetObject("labBall5.Image")));
            this.labBall5.Location = new System.Drawing.Point(251, 67);
            this.labBall5.Name = "labBall5";
            this.labBall5.Size = new System.Drawing.Size(58, 57);
            this.labBall5.TabIndex = 16;
            this.labBall5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labBall19
            // 
            this.labBall19.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labBall19.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.labBall19.Image = ((System.Drawing.Image)(resources.GetObject("labBall19.Image")));
            this.labBall19.Location = new System.Drawing.Point(470, 124);
            this.labBall19.Name = "labBall19";
            this.labBall19.Size = new System.Drawing.Size(58, 57);
            this.labBall19.TabIndex = 25;
            this.labBall19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labBall4
            // 
            this.labBall4.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labBall4.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.labBall4.Image = ((System.Drawing.Image)(resources.GetObject("labBall4.Image")));
            this.labBall4.Location = new System.Drawing.Point(197, 67);
            this.labBall4.Name = "labBall4";
            this.labBall4.Size = new System.Drawing.Size(58, 57);
            this.labBall4.TabIndex = 17;
            this.labBall4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labBall20
            // 
            this.labBall20.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labBall20.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.labBall20.Image = ((System.Drawing.Image)(resources.GetObject("labBall20.Image")));
            this.labBall20.Location = new System.Drawing.Point(524, 124);
            this.labBall20.Name = "labBall20";
            this.labBall20.Size = new System.Drawing.Size(58, 57);
            this.labBall20.TabIndex = 24;
            this.labBall20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labBall3
            // 
            this.labBall3.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labBall3.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.labBall3.Image = ((System.Drawing.Image)(resources.GetObject("labBall3.Image")));
            this.labBall3.Location = new System.Drawing.Point(142, 67);
            this.labBall3.Name = "labBall3";
            this.labBall3.Size = new System.Drawing.Size(58, 57);
            this.labBall3.TabIndex = 18;
            this.labBall3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labBall11
            // 
            this.labBall11.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labBall11.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.labBall11.Image = ((System.Drawing.Image)(resources.GetObject("labBall11.Image")));
            this.labBall11.Location = new System.Drawing.Point(34, 124);
            this.labBall11.Name = "labBall11";
            this.labBall11.Size = new System.Drawing.Size(58, 57);
            this.labBall11.TabIndex = 23;
            this.labBall11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labBall2
            // 
            this.labBall2.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labBall2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.labBall2.Image = ((System.Drawing.Image)(resources.GetObject("labBall2.Image")));
            this.labBall2.Location = new System.Drawing.Point(88, 67);
            this.labBall2.Name = "labBall2";
            this.labBall2.Size = new System.Drawing.Size(58, 57);
            this.labBall2.TabIndex = 19;
            this.labBall2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labSuperBall
            // 
            this.labSuperBall.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labSuperBall.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.labSuperBall.Image = global::BingoBingo.Properties.Resources.red;
            this.labSuperBall.Location = new System.Drawing.Point(592, 118);
            this.labSuperBall.Name = "labSuperBall";
            this.labSuperBall.Size = new System.Drawing.Size(58, 63);
            this.labSuperBall.TabIndex = 20;
            this.labSuperBall.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // labBigSmallBall
            // 
            this.labBigSmallBall.Font = new System.Drawing.Font("微軟正黑體", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.labBigSmallBall.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.labBigSmallBall.Image = ((System.Drawing.Image)(resources.GetObject("labBigSmallBall.Image")));
            this.labBigSmallBall.Location = new System.Drawing.Point(656, 120);
            this.labBigSmallBall.Name = "labBigSmallBall";
            this.labBigSmallBall.Size = new System.Drawing.Size(58, 57);
            this.labBigSmallBall.TabIndex = 21;
            this.labBigSmallBall.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnAgain
            // 
            this.btnAgain.BackColor = System.Drawing.Color.PaleVioletRed;
            this.btnAgain.Font = new System.Drawing.Font("微軟正黑體", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.btnAgain.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.btnAgain.Location = new System.Drawing.Point(682, 410);
            this.btnAgain.Name = "btnAgain";
            this.btnAgain.Size = new System.Drawing.Size(119, 57);
            this.btnAgain.TabIndex = 35;
            this.btnAgain.Text = "Again";
            this.btnAgain.UseVisualStyleBackColor = false;
            this.btnAgain.Click += new System.EventHandler(this.btnAgain_Click);
            // 
            // msgAll
            // 
            this.msgAll.BackColor = System.Drawing.Color.SteelBlue;
            this.msgAll.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.msgAll.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.msgAll.Location = new System.Drawing.Point(278, 381);
            this.msgAll.Name = "msgAll";
            this.msgAll.Size = new System.Drawing.Size(379, 88);
            this.msgAll.TabIndex = 48;
            this.msgAll.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.msgAll.Visible = false;
            // 
            // msg2
            // 
            this.msg2.BackColor = System.Drawing.Color.SeaShell;
            this.msg2.Font = new System.Drawing.Font("微軟正黑體", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.msg2.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.msg2.Location = new System.Drawing.Point(18, 29);
            this.msg2.Name = "msg2";
            this.msg2.Size = new System.Drawing.Size(200, 174);
            this.msg2.TabIndex = 49;
            this.msg2.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.msg2.Visible = false;
            // 
            // msg
            // 
            this.msg.BackColor = System.Drawing.Color.SeaShell;
            this.msg.Controls.Add(this.msg2);
            this.msg.Font = new System.Drawing.Font("微軟正黑體", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.msg.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.msg.Location = new System.Drawing.Point(12, 264);
            this.msg.Name = "msg";
            this.msg.Size = new System.Drawing.Size(235, 217);
            this.msg.TabIndex = 50;
            this.msg.TabStop = false;
            this.msg.Text = "BingoBingo";
            this.msg.Visible = false;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SteelBlue;
            this.ClientSize = new System.Drawing.Size(830, 490);
            this.Controls.Add(this.msg);
            this.Controls.Add(this.msgAll);
            this.Controls.Add(this.btnAgain);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form2";
            this.Text = "BingoBingo開獎訊息";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.groupBox1.ResumeLayout(false);
            this.msg.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label labOddorEvenorDeuceBall;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label labBall18;
        private System.Windows.Forms.Label labBall12;
        private System.Windows.Forms.Label labBall1;
        private System.Windows.Forms.Label labBall13;
        private System.Windows.Forms.Label labBall10;
        private System.Windows.Forms.Label labBall14;
        private System.Windows.Forms.Label labBall9;
        private System.Windows.Forms.Label labBall15;
        private System.Windows.Forms.Label labBall8;
        private System.Windows.Forms.Label labBall16;
        private System.Windows.Forms.Label labBall7;
        private System.Windows.Forms.Label labBall17;
        private System.Windows.Forms.Label labBall6;
        private System.Windows.Forms.Label labBall5;
        private System.Windows.Forms.Label labBall19;
        private System.Windows.Forms.Label labBall4;
        private System.Windows.Forms.Label labBall20;
        private System.Windows.Forms.Label labBall3;
        private System.Windows.Forms.Label labBall11;
        private System.Windows.Forms.Label labBall2;
        private System.Windows.Forms.Label labSuperBall;
        private System.Windows.Forms.Label labBigSmallBall;
        private System.Windows.Forms.Button btnAgain;
        private System.Windows.Forms.Label msgAll;
        private System.Windows.Forms.Label msg2;
        private System.Windows.Forms.GroupBox msg;
    }
}