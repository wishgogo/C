﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp3
{
    class  Order
    {

        public string 訂購品項;
        public int 單價;
        public int 品項杯數;
        public int 品項總價;
        public string 甜度;
        public string 冰塊;
        public string 加料;
        public int 加料價格;

   
    }
   
}
