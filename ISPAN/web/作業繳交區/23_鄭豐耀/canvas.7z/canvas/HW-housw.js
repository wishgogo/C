function doFirst() {
    // 先跟 HTML 畫面產生關聯，再建事件聆聽功能
    let canvas = document.getElementById('canvas')
    context = canvas.getContext('2d')

    // 格線開始
    context.beginPath();
    for (let i = 0; i < 100; i++) {
        let interval = i * 50
        // 水平
        context.moveTo(0, interval);
        context.lineTo(canvas.width, interval);
        context.fillText(interval, 0, interval);

        // 垂直
        context.moveTo(interval, 0);
        context.lineTo(interval, canvas.height);
        context.fillText(interval, interval, 10);
    }
    context.strokeStyle = 'rgba(0,0,0,0.3)';
    context.stroke();
    // =====
    context.beginPath();
    context.lineWidth = 5;
    context.strokeStyle = 'rgb(0,0,0)';
    context.lineCap = 'round';
    // 底610
    context.moveTo(340, 475);
    context.lineTo(350, 610);
    context.lineTo(730, 610);
    context.lineTo(760, 490);
    context.lineTo(675, 285);
    // 左邊外面線
    context.moveTo(640, 260);
    context.lineTo(510, 260);
    context.quadraticCurveTo(460, 240, 400, 230);
    context.quadraticCurveTo(360, 260, 345, 340);
    context.quadraticCurveTo(340, 360, 360, 360);
    context.quadraticCurveTo(360, 320, 400, 275);
    context.quadraticCurveTo(440, 300, 460, 365);
    context.quadraticCurveTo(500, 320, 510, 265);
    context.stroke();
    context.beginPath();
    context.moveTo(400, 230);
    context.quadraticCurveTo(460, 260, 480, 335);
    context.stroke();



    context.beginPath();
    context.moveTo(360, 360);
    context.quadraticCurveTo(320, 410, 320, 460);
    context.quadraticCurveTo(340, 480, 340, 480);
    context.stroke();


    // 左邊窗戶
    context.beginPath();
    context.moveTo(365, 330);
    context.lineTo(375, 400);
    context.lineTo(455, 400);
    context.lineTo(455, 350);
    context.moveTo(410, 400);
    context.lineTo(400, 275);
    context.moveTo(370, 360);
    context.lineTo(455, 360);


    // 內邊框縣
    context.moveTo(675, 285);
    context.lineTo(600, 475);
    context.quadraticCurveTo(590, 490, 557, 470);
    context.quadraticCurveTo(580, 330, 675, 220);
    context.quadraticCurveTo(770, 350, 780, 460);
    context.quadraticCurveTo(790, 500, 760, 490);
    context.moveTo(340, 475);
    context.lineTo(557, 475);
    context.lineTo(557, 610);
    context.stroke();
    //   窗 框

    context.beginPath();
    context.lineCap = 'round';

    context.moveTo(635, 420);
    context.quadraticCurveTo(675, 370, 720, 430);
    context.lineTo(710, 535);
    context.lineTo(630, 532);
    context.closePath();
    context.stroke();
    // 窗內
    context.beginPath();
    context.moveTo(635, 480);
    context.lineTo(710, 483);
    context.stroke();
    context.beginPath();
    context.moveTo(675, 400);
    context.lineTo(670, 530);
    context.stroke();

    //門
    context.beginPath();
    context.moveTo(385, 610);
    context.lineTo(380, 538);
    context.quadraticCurveTo(430, 460, 470, 538);
    context.lineTo(470, 610);
    context.stroke();

    context.beginPath();
    context.arc(450, 560, 10, 0, 2 * Math.PI);
    context.stroke();


    // 煙囪
    context.beginPath();
    context.moveTo(500, 253);
    context.lineTo(500, 225);
    context.quadraticCurveTo(470, 200, 500, 180);
    context.quadraticCurveTo(530, 177, 575, 180);
    context.quadraticCurveTo(600, 200, 575, 220);
    context.lineTo(575, 260);
    context.stroke();

    context.beginPath();
    context.moveTo(573, 220);
    context.quadraticCurveTo(540, 230, 495, 220);


    // 

















    // 外邊框線







    context.stroke();



}
window.addEventListener('load', doFirst)