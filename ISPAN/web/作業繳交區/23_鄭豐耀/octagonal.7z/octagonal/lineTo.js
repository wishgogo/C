function doFirst() {
    let canvas = document.getElementById('canvas')
    context = canvas.getContext('2d')


    let r = 100;
    context.strokeStyle = 'gold';
    context.lineWidth = 3;
    context.beginPath();
    context.moveTo(350, 250);
    context.lineTo(500, 350);
    context.lineTo(250 + r * Math.cos(Math.PI / 4), 250 + r * Math.sin(Math.PI / 4));
    context.lineTo(350, 500);
    context.lineTo(250 + r * Math.cos(Math.PI / 2), 250 + r * Math.sin(Math.PI / 2));
    context.lineTo(150, 500);
    context.lineTo(250 + r * Math.cos(Math.PI * 3 / 4), 250 + r * Math.sin(Math.PI * 3 / 4));
    context.lineTo(0, 350);
    context.lineTo(250 + r * Math.cos(Math.PI), 250 + r * Math.sin(Math.PI));
    context.lineTo(0, 150);
    context.lineTo(250 + r * Math.cos(Math.PI * 5 / 4), 250 + r * Math.sin(Math.PI * 5 / 4));
    context.lineTo(150, 0);
    context.lineTo(250 + r * Math.cos(Math.PI * 3 / 2), 250 + r * Math.sin(Math.PI * 3 / 2));
    context.lineTo(350, 0);
    context.lineTo(250 + r * Math.cos(Math.PI * 7 / 4), 250 + r * Math.sin(Math.PI * 7 / 4));
    context.lineTo(500, 150);
    context.lineTo(350, 250);
    context.stroke();
}

window.addEventListener('load', doFirst)