window.addEventListener('load', doFirst)
function doFirst() {
  const context = document.querySelector('#canvas').getContext('2d')

  for (let i = 0; i < 100; i++) {
    let interval = i * 20
    //水平
    context.moveTo(0, interval)
    context.lineTo(canvas.width, interval);
    context.fillText(interval, 0, interval);
    //垂直
    context.moveTo(interval, 0);
    context.lineTo(interval, canvas.height)
    context.fillText(interval, interval, 10);
  }
  context.strokeStyle = '#f6f6f6'
  context.stroke();

  // ========
  context.strokeStyle = '#000'
  context.lineWidth = 1

  context.beginPath()
  context.moveTo(140, 80);
  context.lineTo(440, 80)
  context.lineTo(440, 380);
  context.lineTo(140, 380);
  context.closePath();
  context.stroke()

  //1
  // context.beginPath()
  // context.moveTo(290, 80)
  // context.lineTo(290, 169);
  // context.stroke();

  //up
  context.beginPath();
  context.moveTo(215, 80);
  context.lineTo(290, 169);
  context.stroke();

  context.beginPath();
  context.moveTo(365, 80);
  context.lineTo(290, 169);
  context.stroke();

  //down
  context.beginPath()
  context.moveTo(215, 380);
  context.lineTo(290, 291);
  context.stroke()

  context.beginPath();
  context.moveTo(365, 380);
  context.lineTo(290, 291);
  context.stroke();
  

  // 2
  // context.beginPath();
  // context.moveTo(140, 230);
  // context.lineTo(229, 230);
  // context.stroke();

  //left
  context.beginPath();
  context.moveTo(140, 155);
  context.lineTo(229, 230);
  context.stroke();
  
  context.beginPath();
  context.moveTo(140, 305);
  context.lineTo(229, 230);
  context.stroke()
  
  //right
  context.beginPath()
  context.moveTo(440, 155);
  context.lineTo(351, 229);
  context.stroke()

  context.beginPath()
  context.moveTo(440, 305)
  context.lineTo(351, 230);
  context.stroke();
  
  //2
  context.beginPath()
  context.moveTo(250, 270);
  context.lineTo(140, 305);
  context.stroke()

  context.beginPath()
  context.moveTo(250, 270);
  context.lineTo(215, 380);
  context.stroke();
  
  
    
  //3
  context.beginPath()
  context.moveTo(330, 270);
  context.lineTo(365, 380)
  context.stroke();
  
  context.beginPath()
  context.moveTo(330, 270);
  context.lineTo(440, 305);
  context.stroke();
  
  //4
  context.beginPath();
  context.moveTo(330, 190);
  context.lineTo(365, 80);
  context.stroke();
  
  context.beginPath();
  context.moveTo(330, 190);
  context.lineTo(440, 155);
  context.stroke();
  

  context.beginPath();
  context.moveTo(250, 190);
  context.lineTo(140, 155);
  context.stroke()

  context.beginPath()
  context.moveTo(250, 190);
  context.lineTo(215, 80);
  context.stroke();
  
  
  
}