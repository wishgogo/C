function doFirst() {
    let canvas = document.getElementById('canvas')
    context = canvas.getContext('2d')

    // 格線
    // for (let index = 0; index < 100; index++) {
    //     let interval = index * 50
    //     //Horizontal
    //     context.moveTo(0, interval);
    //     context.lineTo(canvas.width, interval);
    //     context.fillText(interval, 0, interval);


    //     //Vertical        
    //     context.moveTo(interval, 0);
    //     context.lineTo(interval, canvas.height);
    //     context.fillText(interval, interval, 10);
    // }
    // context.strokeStyle = 'rgba(0,0,0,0.3)';
    // context.stroke();

    // ===

    //輔助圓
    // context.strokeStyle = 'green';
    // context.lineWidth = 5;

    // context.beginPath();
    // context.arc(250, 250, 100, 0, Math.PI * 2);
    // context.stroke();

    //畫正八角星形
    let r = 100;
    context.strokeStyle = 'gold';
    context.lineWidth = 3;
    context.beginPath();
    context.moveTo(350, 250);
    context.lineTo(500, 350);
    context.lineTo(250 + r * Math.cos(Math.PI / 4), 250 + r * Math.sin(Math.PI / 4));
    context.lineTo(350, 500);
    context.lineTo(250 + r * Math.cos(Math.PI / 2), 250 + r * Math.sin(Math.PI / 2));
    context.lineTo(150, 500);
    context.lineTo(250 + r * Math.cos(Math.PI * 3 / 4), 250 + r * Math.sin(Math.PI * 3 / 4));
    context.lineTo(0, 350);
    context.lineTo(250 + r * Math.cos(Math.PI), 250 + r * Math.sin(Math.PI));
    context.lineTo(0, 150);
    context.lineTo(250 + r * Math.cos(Math.PI * 5 / 4), 250 + r * Math.sin(Math.PI * 5 / 4));
    context.lineTo(150, 0);
    context.lineTo(250 + r * Math.cos(Math.PI * 3 / 2), 250 + r * Math.sin(Math.PI * 3 / 2));
    context.lineTo(350, 0);
    context.lineTo(250 + r * Math.cos(Math.PI * 7 / 4), 250 + r * Math.sin(Math.PI * 7 / 4));
    context.lineTo(500, 150);
    context.lineTo(350, 250);
    context.stroke();
}

window.addEventListener('load', doFirst)