// 25_趙汝穎
function doFirst() {
    // barsize = 636
    // 先跟 HTML 畫面產生關聯
    myMovie = document.getElementById('myMovie')
    playButton = document.getElementById('playButton')
    defaultBar = document.getElementById('defaultBar')
    progress = document.getElementById('progress')
    stopButton = document.getElementById('stopButton')
    upButton = document.getElementById('upButton')
    downButton = document.getElementById('downButton')
    mutedButton = document.getElementById('mutedButton')
    numVolume = document.getElementById('numVolume')

    barsize = parseInt(window.getComputedStyle(defaultBar).width)
    // alert(barsize)

    // 再建事件聆聽功能
    playButton.addEventListener('click', playOrPause)
    myMovie.addEventListener('click', playOrPause)
    defaultBar.addEventListener('click', clickedBar)
    stopButton.addEventListener('click', stop)
    upButton.addEventListener('click', volumeUp)
    downButton.addEventListener('click', volumeDown)
    mutedButton.addEventListener('click', mute)

    // 全螢幕
    // document.getElementById('fullButton').addEventListener('click',function(){
    //     myMovie.webkitEnterFullScreen()
    // });
}
// 播放or暫停
function playOrPause() {
    if (!myMovie.paused && !myMovie.ended) {   // 影片正在跑
        myMovie.pause()
        playButton.innerText = 'play'
    } else {
        myMovie.play()
        playButton.innerText = 'pause'
        setInterval(update, 300)
    }
}
//更新進度條
function update() {
    if (!myMovie.ended) {
        let size = barsize / myMovie.duration * myMovie.currentTime
        progress.style.width = `${size}px`
    } else {
        progress.style.width = `0px`
        myMovie.currentTime = 0
        playButton.innerText = 'play'
    }
}
//點選進度條
function clickedBar(e) {
    let mouseX = e.pageX - defaultBar.offsetLeft
    progress.style.width = `${mouseX}px`

    let newTime = mouseX / (barsize / myMovie.duration)
    myMovie.currentTime = newTime
}
//停止播放
function stop() {
    myMovie.pause()
    progress.style.width = `0px`
    myMovie.currentTime = 0
    playButton.innerText = 'play'
}
//音量增加
function volumeUp() {
    if (myMovie.volume < 1) {
        myMovie.volume = (myMovie.volume * 10 + 1) / 10
        console.log(myMovie.volume)
        showVolume()
    } else {
        showVolume()
    }
}
//音量減少
function volumeDown() {
    if (myMovie.volume > 0) {
        myMovie.volume = (myMovie.volume * 10 - 1) / 10
        console.log(myMovie.volume)
        showVolume()
    } else {
        showVolume()
    }
}
//靜音
function mute() {
    if (myMovie.volume != 0) {
        preVolume = myMovie.volume
        myMovie.volume = 0
        console.log('preVolume = ' + preVolume)
        console.log('myMovie.volume = ' + myMovie.volume)
        mutedButton.innerText = 'Unmute'
        showVolume()
    } else {
        myMovie.volume = preVolume
        console.log('preVolume = ' + preVolume)
        console.log('myMovie.volume = ' + myMovie.volume)
        mutedButton.innerText = 'Mute'
        showVolume()
    }
}
//顯示音量
function showVolume() {
    numVolume.innerHTML = 'Volume = ' + myMovie.volume * 100;
    //setTimeout(() => { numVolume.innerHTML = ''; }, 2000)
}
window.addEventListener('load', doFirst)